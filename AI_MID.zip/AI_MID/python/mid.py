import heapq
from collections import deque

class Graph:
    def __init__(self):
        self.graph = {
            'S': [('B', 5), ('A', 2)],
            'A': [('C', 3), ('G', 10)],
            'B': [('D', 2), ('E', 4)],
            'C': [('D', 1), ('G', 4)],
            'D': [('G', 6)],
            'E': [],
            'G': []
        }

        self.heuristic = {
            'S': 8,  
            'A': 6,   
            'B': 7,  
            'C': 3, 
            'D': 5,       
            'E': 0,      
            'G': 0       # Goal has heuristic 0
        }
        # All heuristics are less than or equal to actual minimum cost
        
       
        # traversal starts at node S 
        # node B is marked as refuel station
        # node C has med kit which must be visited
        # upon visitng each node the fuel reduces, we must reach node G before fuel == 0
        # if time t >= 8 the path from C to G becomes blocked

        # A* algorithm uses priority queue
        def a_star(self, start, goal):
        
           
            fuel=22
            t=0
            g_score = {start: 0}
            f_score = {start: self.heuristic[start]}
            
            open_set = [(f_score[start], counter, start, [start], 0)]
            open_set_nodes = {start}
           
            best_g = {start: 0}
            
            closed_set = set()
            expanded_nodes = 0
            nodes_explored_order = []
            
            print(f"\nInitial state:")
            print(f"  Start node: {start}, Goal node: {goal}")
            print(f"  h({start}) = {self.heuristic[start]}")
            print(f"  Initial f({start}) = 0 + {self.heuristic[start]} = {f_score[start]}")
        
            while open_set:
                
                current_f, _, current_node, path, current_g = heapq.heappop(open_set)
                open_set_nodes.remove(current_node)
                nodes_explored_order.append(current_node)
                expanded_nodes += 1
                fuel=fuel-1
                t=t+1
                
                
                closed_set.add(current_node)

                # refuel if B node visited as it is the refuel station
                if current_node == 'B':
                    fuel=22
                    print("refueling")

                # checkinmg of node C is visited
                visited_c=False
                
                if current_node=='C':
                    visited_c=True

                g= new_time
                h=heuristic[current_node]
                f=g+h
                
                neighbors = self.graph.get(current_node, [])
                print(f"  Neighbors: {[(n, w) for n, w in neighbors]}")
                
                # if time reaches 8 then path is blocked
                if t>=8:
                    print("path is blocked")
                    open_set.remove('C')

                if not neighbors:
                    print("  No outgoing edges from this node")
                
                # fuel == 0
                if fuel == 0:
                    print("Mission Failed")
                    exit
                if current_node == goal:
                    print(f"\n{''*20}")
                    print(f"GOAL FOUND!")
                    print(f"  Final Path: {' -> '.join(path)}")
                    print(f"  Total Path Cost: {current_g}")
                    print(f"  Nodes explored in order: {' -> '.join(nodes_explored_order)}")
                    return path, expanded_nodes, current_g
                





